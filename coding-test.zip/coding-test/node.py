"""
Used by Challenge 1
"""

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
